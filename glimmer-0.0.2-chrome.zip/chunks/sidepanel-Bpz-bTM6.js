const e="繁體中文",a={name:e};export{a as default,e as name};
