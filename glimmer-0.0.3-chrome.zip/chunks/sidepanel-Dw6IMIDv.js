const e="english",n={name:e};export{n as default,e as name};
