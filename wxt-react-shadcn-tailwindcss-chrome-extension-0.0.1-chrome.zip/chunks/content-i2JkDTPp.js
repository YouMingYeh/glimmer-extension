const t="中文繁體",n="設定",o="關於",c="聯絡",s={contentName:t,settings:n,about:o,contact:c};export{o as about,c as contact,t as contentName,s as default,n as settings};
