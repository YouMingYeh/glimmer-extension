const t="中文简体",n="设置",o="关于",c="联系",s={contentName:t,settings:n,about:o,contact:c};export{o as about,c as contact,t as contentName,s as default,n as settings};
