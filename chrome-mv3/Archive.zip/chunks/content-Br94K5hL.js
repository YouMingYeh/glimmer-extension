const t="english",n="Settings",o="About",c="Contact",s={contentName:t,settings:n,about:o,contact:c};export{o as about,c as contact,t as contentName,s as default,n as settings};
