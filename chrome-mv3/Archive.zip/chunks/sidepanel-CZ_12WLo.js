const e="中文简体",a={name:e};export{a as default,e as name};
